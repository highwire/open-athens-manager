import { Component, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { FormControl, FormGroup } from '@angular/forms';

import { HTTPService } from '../../services/http.service';
import { BaseService } from 'src/app/services/base.service';
import { hwValidator } from '../../services/hwvalidator.service';
import {MatPaginator,PageEvent} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';

import * as $ from 'jquery';



// declare var mychart: any;   //custom module declare


 


@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})

export class ChartsComponent implements OnInit {
  currency=[]
  pricearray:any;
  displayedColumns: string[] = ['name', 'description','options', 'productType','price_interval','price_amount'];  
  freeLabel= 'Free';
  notForSaleLabel= 'Not for Sale';
  clickedRows = new Set<any>();
  products: any;
  isLoading = false;
  totalRows = 0;
  pageSize = 5;
  currentPage = 0;
  pageSizeOptions: number[] = [5, 10, 25, 100];
  animal: any;
  name: any;
  // publications:any

  accessPeriods= [
    {label: '24 Hours', value: 24, sort: 24},
    {label: '48 Hours', value: 48, sort: 48},
    {label: '72 Hours', value: 72, sort: 72},
    {label: '7 Days', value: 168, sort: 168},
    {label: '3 Months', value: 2160, sort: 2160},
    {label: '6 Months', value: 4320, sort: 4320},
    {label: '1 Year', value: 8760, sort: 8760},
    {label: '2 Years', value: 17520, sort: 17520},
    {label: 'Perpetual', value: -1, sort: 99999}
  ]


  
  chart: any;

  // Click(): void{
  //   sum()
  // }


  sitedata: any;
  

  response:any;


  dateRange = new FormGroup({
    start: new FormControl(),
    end: new FormControl()
  });

  // displayedColumns: string[] = [
  //   'contentId',
  //   'title',
  //   'resourceType',
  //   'amount',
  //   'interval',
  //   'qty',
  //   'revenue'
  // ];
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  
  // clickedRows = new Set<any>();
  // products: any;
  // isLoading = false;
 
  // pageSizeOptions: number[] = [10, 25, 100];
  // animal: any;
  // name: any;







  constructor(public http: HTTPService,
    public base: BaseService,
    public hwv: hwValidator,
  ) { }




  ngOnInit(): void {

   
  
    // new mychart();   //used for customjs


    this.dateRange.patchValue({
      start: "2021-03-11T06:22:48.070Z",
      end: "2022-03-03T06:22:48.070Z"
   });

    
   this.selectAllPublishers();

   this.selectAllListPublishers();
  // this.getChartdata();
   this.getCurrencyList();
   this.getChartview();
  
  // this.getchartdata()



    this.chart = document.getElementById("chart");
    Chart.register(...registerables);
    this.loadChart();
  }

  
  


  setDate(): void{
    // Start: {{dateRange.value.start | date}}
    // End: {{dateRange.value.end | date}}
  }


  selectAllListPublishers(){
    let publisher = localStorage.getItem('publisher')  ;
    let URL= this.base.PRODUCT_LIST+ publisher+'/products';  //----------
    this.http.getDatawithGet(URL,publisher).subscribe((data:any)=>{
        console.log(data);
        // this.filterDOI(data);
       
    })
  }

  selectAllPublishers(){
    let publisher = localStorage.getItem('publisher')  ;
    let URL= this.base.SITE_LIST;
    var data={
      pubTerm: publisher,
      role: "Intelligent Commerce Pricing and Reporting UI",
      userId: "2"
    }
    this.http.getDatawithPost(URL,data).subscribe((data:any)=>{
        console.log(data);             
        this.sitedata=  data.sites;
    })
  }
  formatAmountDisplay(amount:any) {
    if (amount === -1) {
      return this.notForSaleLabel;
    }
    else if (amount === 0) {
      return this.freeLabel;
    }
    return amount;
  }
  filterDOI(data:any)
  {
    var self= this;
    data= data.filter((entry:any)=>{
      debugger;
    // return  self.hwv.doi(item.name);
      return(entry.productType=='ebook' )
      // && entry.name=='chapter-price' ) ||
      // (entry.productType=='ebook' && entry.name=='edition-price' )
    });
  // console.log('filterDOI',data);
  this.extractPrice(data);

}
extractPrice(data:any){
  var self= this;
  var pricearray:any= [];
  data.forEach((element:any) => {
    console.log(element);
    if(element.prices && Array.isArray(element.prices)){
      element.prices.forEach((elements:any) => {   
        if(elements.name=='chapter-price'  || elements.name=='edition-price' )
      // (entry.productType=='ebook' && entry.name=='edition-price' )
        pricearray.push({
          name: element.name,
          productType:element.productType,
          description:element.description,      
          identifier: element.identifier,
          price_amount: self.formatAmountDisplay (elements.amount),
          price_currency:elements.currency,
          price_interval:elements.interval,
          price_name:elements.name
        })  
      });      
    }    
  });


  this.pricearray=  pricearray;
  console.log('this.pricearray',this.pricearray);


} 


update(){
  let publisher = localStorage.getItem('publisher')  ;
  var name = this.pricearray[0].name.replace('/', '!2F')
  let URL= this.base.DELETE_PRICE+ publisher +'/products/'+ name;  //-------------
  console.log(URL);

  var prices= this.checkPricealreayexit();
  var data={
      corpus: null,
      description: this.pricearray[0].description,
      identifier: this.pricearray[0].identifier,
      name: this.pricearray[0].name,
      prices: prices,
      productType: this.pricearray[0].productType

  }
  console.log(data);
  this.http.getDatawithPut(URL,data).subscribe((res:any)=>{
    this.base.openSnackBar(5,'Updated successful.');
    this.selectAllListPublishers();
  })

}
setAssess(a:any,b:any){
  b.price_interval=a.value;
  b.price_interval_label=a.label;


}
checkPricealreayexit(){
  var prices:any
  prices=[];
  this.pricearray.forEach((element:any) => {
    // if(element.price_interval==this.data.element.price_interval 
      // && element.price_currency == this.data.element.price_currency)
      // element.price_amount=  this.data.element.price_amount    
      prices.push({
        name: element.price_name, 
        amount: element.price_amount,
         currency: element.price_currency,
         interval: element.price_interval
      });     
  });
  return prices;
}
getCurrencyList(){
  let publisher = localStorage.getItem('publisher')  ;
  // var name =  window.encodeURIComponent(this.basedata.element.name)
  let URL= this.base.CURRENCY_LIST+publisher+ '/currencies';
  this.http.getDatawithGet(URL,'').subscribe((res:any)=>{
    this.currency  =  res;
      console.log(res);       
  })

}

  // getChartdata(){
  //   let publisher = localStorage.getItem('publisher')  ;
  //   let URL= this.base.Chart_data+ publisher;
  //   this.http.getDatawithGet(URL,publisher).subscribe((data:any)=>{
  //       console.log(data);
  //       this.sitedata
  //       this.filterDOI(data);
       
  //   })
  // }


  
      

  




  loadChart(): void {
    
  //   new Chart(this.chart, {
  //     type: 'bar',
      
      
  //     data: {
        
  //       datasets: [{
  //         label: 'Grouped',
          
          
  //         data: [],
  //         backgroundColor: [
  //           'rgba(255, 99, 132, 0.5)',
  //           // 'rgba(255, 159, 64, 0.5)',
  //           // 'rgba(255, 205, 86, 0.5)',
  //           // 'rgba(75, 192, 192, 0.5)',
  //           // 'rgba(54, 162, 235, 0.5)',
  //           // 'rgba(153, 102, 255, 0.5)',
  //           // 'rgba(201, 203, 207, 0.5)',
  //           // 'rgba(153, 102, 254, 0.5)',
  //           // 'rgba(201, 203, 239, 0.5)',
  //           // 'rgba(153, 102, 234, 0.5)',
  //           // 'rgba(201, 203, 218, 0.5)',
  //           // 'rgba(201, 214, 290, 0.5)',
  //         ]
  //       },
        
  //       {
          
  //         data:[],
          
          
  //         label: 'Stacked',
          
  //         backgroundColor: [
  //           'rgba(255, 99, 132, 0.2)'
  //           // 'rgba(255, 159, 64, 0.2)',
  //           // 'rgba(255, 205, 86, 0.2)',
  //           // 'rgba(75, 192, 192, 0.2)',
  //           // 'rgba(54, 162, 235, 0.2)',
  //           // 'rgba(153, 102, 255, 0.2)',
  //           // 'rgba(201, 203, 207, 0.2)',
  //           // 'rgba(153, 102, 254, 0.2)',
  //           // 'rgba(201, 203, 239, 0.2)',
  //           // 'rgba(153, 102, 234, 0.2)',
  //           // 'rgba(201, 203, 218, 0.2)',
  //           // 'rgba(201, 214, 290, 0.2)',
  //         ],
  //         borderColor: [
  //           'rgb(255, 99, 132)'
  //           // 'rgb(255, 159, 64)',
  //           // 'rgb(255, 205, 86)',
  //           // 'rgb(75, 192, 192)',
  //           // 'rgb(54, 162, 235)',
  //           // 'rgb(153, 102, 255)',
  //           // 'rgb(201, 203, 207)'],
  //         ]
  //       },
        
  //       ],
          
  //       labels: ['Jan', 'Feb', 'Mar', 'April', 'May', 'Jun', 'July', 'Aug', 'Sept', 'Oct', "Nov", 'Dec'],
  //     },
  //     options: {
  //       responsive: true,
  //       maintainAspectRatio: false,
  //       scales: {
  //         y: {
            
  //           beginAtZero: true,
  //           // display:false //agar grid hatani ho
  //         }
  //       }
  //     }
  //   })

  new Chart(this.chart, {
    type: 'bar',
    data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [{
            label: "Grouped",
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                // 'rgba(54, 162, 235, 0.2)',
                // 'rgba(255, 206, 86, 0.2)',
                // 'rgba(75, 192, 192, 0.2)',
                // 'rgba(153, 102, 255, 0.2)',
                // 'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                // 'rgba(54, 162, 235, 1)',
                // 'rgba(255, 206, 86, 1)',
                // 'rgba(75, 192, 192, 1)',
                // 'rgba(153, 102, 255, 1)',
                // 'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
               
                beginAtZero: true
            }
        }
    }
});
  }

  ///my code

  // getchartdata(){
  //   let publisher = localStorage.getItem('gsl')  ;
  //   let URL= this.base.Chart_data+ publisher  //----------
  //   this.http.getDatawithPost(URL,publisher).subscribe((data:any)=>{
  //       console.log(data);
  //       // this.filterDOI(data);
       
  //   })
  // }
  
  getChartview(){
  debugger
  let publisher = localStorage.getItem('publisher')  ;
    let URL= this.base.Chart_data+  publisher;
    // "pub": publisher,
    let DATA={"options": {
      // "endDate": this.dateRange.value.s
      "end": this.dateRange.value.end,
      
      "start": this.dateRange.value.start
    }}
    this.http.getDatawithPost(URL,DATA).subscribe((data:any)=>{
      this.dataSource.data= data.data;
      this.response= data;});
}


 
  




  
}